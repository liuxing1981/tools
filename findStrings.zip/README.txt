Description:
  The tool could help you to find one or more the one words from a directory (included all files and sub-directory).
  If you want to find some words in different lines, please try to use it.
  For example:
      Assume there is a file like this:
      1    hello everyone
      2    hello world
      3    I like this world.
      4    hello big word

      Use this tool to find “hello” and “world”. The line 1 and line 3 will be found.
   If you use grep command like this : 
grep “hello.*world”
The line 2 and line 4 will be found.

Feature:
1.	specific file suffix
2.	use muti-thread(fork-join) more efficient
I have wrote a shell scrip to do the same thing using grep command. It took more than 10mins, while this tool will took only less 2mins for searching the same file.

Compare with grep command
1. You can only use grep command to find words at one line. Just like the above example.
  2. grep command: The more words you want to find, the more time cost.
This tool: The more words you want to find, the time cost is a little raise.

How to use:
java –DsearchPath=e:\software –Dext=js –jar findStrings.jar word1 word2 word3

searchPath: the directory you want to search.
ext: the suffix of the file. Support more ext use comma . ex: -Dext=js,txt  #to find js and txt files
word1,word2,word3 are the finding words. Support unlimited finding words.	

Luis
